<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
        <table>
          <tr>
            <th>student name</th>
            <th>student id</th>
            <th>sec</th>
            <th>marks </th>
          </tr>
          <tr>
              <td>ashik</td>
              <td>18-37</td>
              <td>A</td>
              <td>80</td>
          </tr>
          <tr>
              <td>amin</td>
              <td>18-87</td>
              <td>A</td>
              <td>90</td>
          </tr>
        </table>
  </body>
</html>
